<?php
 include("dbconn.php");

 $countError = 0;
 $name_error = $surame_error = $stNum_error = $email_error = $password_error = $confPassword_error = "";
 $name = $surname = $stNum = $email = $password = $confirmPassword = "";

 if(isset($_POST["submit"]))
 {
    if(empty($_POST['name']))
    {
      $name_error = "Please input the first name.";
      $countError++;
    }
    else
    {

      $name = $_POST['name'];
    }

    if(empty($_POST['surname']))
    {
      $surame_error = "Please input the surname.";
      $countError++;
    }
    else
    {
      $surname = $_POST['surname'];
    }

    if(empty($_POST['email']))
    {
      $email_error = "Please input the email address.";
      $countError++;
    }
    else
    {
      $email = $_POST['email'];
    }

    if(empty($_POST['stNum']))
    {

      $stNum_error = "Please input the Student Number.";
      $countError++;
    }
    else
    {
      $stNum = $_POST['stNum'];
    }

    if(empty($_POST['pswSet']))
    {
      $password_error = "Please input the password.";
      $countError++;
    }
    elseif(strlen($_POST["pswSet"]) < 6)
    {
      $password_error = "Please ensure that your password is no less than 6 characters.";
      $countError++;
    }
    else
    {
      $password = $_POST['pswSet'];
    }

    if(empty($_POST['pswSetRe']))
    {

      $confPassword_error = "Please input confirm your password.";
      $countError++;
    }
    else
    {
      $confirmPassword = $_POST['pswSetRe'];

      if(empty($password_error) && ($password != $confirmPassword))
      {
        $confPassword_error = "Error! Password does not match confirmed password.";
      }
    }



    if($countError == 0)
    {
        //Not sure if hashing works.
        $param_password = password_hash($password, PASSWORD_DEFAULT);

        //Insert into a table in database, query  ---NOT SURE WHAT TABLES ATTRIBUTES ARE????
        $sql = "INSERT INTO user (user_id, firstname, lastname, email, stNum)
                VALUES (NULL, '$name', '$surname', '$email', '$stNum', '$param_password', '$confirmPasswords')";
    

      //query execution
      $dbResult = mysqli_query($dbconnect, $sql);

      if ($dbResult === FALSE) 
      {
        echo "Insert error: ". mysqli_connect_error();
      } 
      else 
      { 
        //insert values have succesfully been inserted.
        session_start();
        $_SESSION['message'] = "User has been registered succesfully.";
        $_SESSION['msg_type'] = "success";
        header('location:login.php');
      }

        //closing the connection
        mysqli_close($dbconnect);
        $dbconnect = FALSE;
    }
    unset($_POST["submit"]);
 }


?>