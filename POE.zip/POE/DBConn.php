<?php
 $dbName = "bookstore";
 $server = "localhost";
 $username = "root";
 $pswd = "";

 $dbconnect = @mysqli_connect($server, $username, $pswd, $dbName);

 if($dbconnect === FALSE){
     echo "<p>Connection error: " . mysqli_error($dbconnect) . "</p>";
     @mysqli_close($dbconnect);
     $dbconnect = FALSE;
 }else{
  //echo "Successfiul Connection";
 }


?>

