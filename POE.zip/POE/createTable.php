<?php

include("DBConn.php");

/*
Megan
Mulder
ST10116509
*/

//Notes -- p464!!!!!!!
//Declare the variables
/*$servername = "localhost";
$username = "root";
$password = "";

//establishing connection 
$connectMyDB = mysqli_connect($servername, $username, $password);

//checking connection
if ($connectMyDB === FALSE) 
{
  echo "<p>Failed to connect to MySQL: " . mysqli_connect_error() . "</p>";
  exit();//Do not continue, go out!
}*/

//Code to see if Table Exists
$isFound = mysqli_query($dbconnect, "SELECT * FROM tblbuyer");//(www.learningaboutelectronics.com, n.d.)

if($isFound !== FALSE)//check if statement
{
   echo("The table exist in the database.");//message to user

   //Calls below functions
   deleteTbl();
   //createOrRecreateTbl();
   //loadTxtFile();
}
else
{
   echo("The table does not exist in the database.");//message to user
}

//Delete an existing tbl
function deleteTbl()
{
    $nowDelete = mysqli_query($dbconnect, "DROP TABLE tblbuyer");

    if(!$nowDelete)
    {
        echo("<p>Error! The table 'tblbuyer' was not dropped: " . mysqli_error($dbconnect) . "</p>");
    }
    else
    {
        echo("<p>The table 'tblbuyer' was succesfully dropped</p>");
        createOrRecreateTbl();
    }
}

//(Re)create a tbl
function createOrRecreateTbl()
{
    $createTable = "CREATE TABLE tblbuyer()";
    //BuyerName
/*BuyerSurname
BuyerEmail
19 | P a g e
BuyerPassword
UsernameBuyer
StudentNumber*/


    $nowCreate = mysqli_query($dbconnect, $createTable);

    if(!$nowCreate)
    {
        echo("<p>Error! The table 'tblbuyer' was not created: " . mysqli_error($dbconnect) . "</p>");
    }
    else
    {
        echo("<p>The table 'tblbuyer' was succesfully created</p>");
        loadTxtFile();
    }
}

//Load text file data in database tbl
function loadTxtFile()
{
    $loadSql = "LOAD DATA LOCAL INFILE 'C:\wamp64\www\POE' INTO TABLE tblbuyer() FIELDS TERMINATED BY ','";
}

/*
Reference:

www.learningaboutelectronics.com. (n.d.). How to Check if a MySQL Table Exists Using PHP. [online] Available at: http://www.learningaboutelectronics.com/Articles/How-to-check-if-a-MySQL-table-exists-using-PHP.php [Accessed 7 Jun. 2022].

*/

?>
